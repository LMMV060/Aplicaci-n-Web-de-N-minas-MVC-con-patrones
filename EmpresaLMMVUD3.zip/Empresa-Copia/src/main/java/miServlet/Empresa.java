package miServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class Empresa
 */
@WebServlet("/Empresa")
public class Empresa extends HttpServlet {
	private static final long serialVersionUID = 1L;

	

    /**
     * Default constructor. 
     */
    public Empresa() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String var = request.getParameter("num");
		System.out.println(var);
		String i;
		if(var == null) {
			i = "1";
		} else {
			i = var;
		}
		
		PrintWriter out = response.getWriter();
		switch(i) {
		case "1":
			
			try{
	    		Class.forName("com.mysql.jdbc.Driver");
	    		Connection conBD = DriverManager.getConnection(
	    	            "jdbc:mysql://localhost:3306/evaluacion",
	    	            "root", "123456");
	    		
	    		 if (!conBD.isClosed())
	    		   {
	    		      // La consulta
	    		      Statement st = conBD.createStatement();
	    		      ResultSet rs = st.executeQuery("select * from empleados" );

	    		      // Ponemos los resultados en un table de html
	    		      out.println("<table border=\"1\"><tr><td>Nombre</td><td>Sexo</td><td>DNI</td><td>Categoria</td></td><td>A�os</td></tr>");
	    		      while (rs.next())
	    		      {
	    		    	  out.println("<tr>");
	    		    	  out.println("<td>"+rs.getObject("nombre")+"</td>");
	    		    	  out.println("<td>"+rs.getObject("sexo")+"</td>");
	    		    	  out.println("<td>"+rs.getObject("dni")+"</td>");
	    		    	  out.println("<td>"+rs.getObject("categoria")+"</td>");
	    		    	  out.println("<td>"+rs.getObject("anyos")+"</td>");
	    		    	  out.println("</tr>");
	    		      }
	    		      out.println("</table>");
	    		      
	    		      out.println("<p><a href=\"index.jsp\">Volver</a></p>");

	    		      // cierre de la conexion
	    		      conBD.close();
	    		   }else{
	    			// Error en la conexion
	    			   out.println("fallo");
	    		   }
	    		      
	    		
	    	} catch (Exception error) {
	    	    System.out.println("Error al conectar con el servidor MySQL/MariaDB: " + error.getMessage());
	    	}
			break;
		case "2":
			
			try {	
				String DNI = request.getParameter("DNI");
	    		Class.forName("com.mysql.jdbc.Driver");
	    		Connection conBD = DriverManager.getConnection(
	    	            "jdbc:mysql://localhost:3306/evaluacion",
	    	            "root", "123456");
	    		
	    		 if (!conBD.isClosed())
	    		   {
	    		      // La consulta
	    		      Statement st = conBD.createStatement();
	    		      ResultSet rs = st.executeQuery("select * from nomina where dni like '" + DNI + "';" );
	    		      rs.next();
	    		      if(DNI.equals(rs.getObject("dni"))) {
	    		  		out.println("<html><body>");
	    		  		out.println("<h1> El DNI " + DNI + " tiene un salario de "+rs.getObject("SUELDO_BASE")+"</h1>");
	    		  		out.println("<a href=\"busqueda.jsp\">Volver</a>");
	    		  		out.println("</body></html>");
	    		      } else {
	    		    	  RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
	       			   	  rd.forward(request, response);
	    		      }
	    		      // cierre de la conexion
	    		      conBD.close();
	    		   }else{
	    			   RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
	    			   rd.forward(request, response);
	    		   }
	    		      
	    		
	    	} catch (Exception error) {
	    		RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
				rd.forward(request, response);
	    	}
				break;
				
		case "3":
			try{
				 
				String Valor = request.getParameter("Valor");
				String categoria = request.getParameter("Parametro");
				String cantidad = request.getParameter("quantity");
	    		Class.forName("com.mysql.jdbc.Driver");
	    		Connection conBD = DriverManager.getConnection(
	    	            "jdbc:mysql://localhost:3306/evaluacion",
	    	            "root", "123456");
	    		
	    		 if (!conBD.isClosed())
	    		   {	//La consulta
	    		      Statement st = conBD.createStatement();
	    		      ResultSet rs = st.executeQuery("select * from empleados where dni like '" + Valor + "' or nombre like '"+ Valor +"';" );
	    		      rs.next();
	    		      if(Valor.equals(rs.getObject("dni"))) {
	    		    	  st.executeUpdate("Update empleados set " + categoria + " = " + cantidad + " where dni like '" + Valor + "';");
	    		      } else {
	    		    	  if(Valor.equals(rs.getObject("nombre"))) {
	    		    		  
	    		    		  st.executeUpdate("Update empleados set " + categoria + " = " + cantidad + " where nombre like '" + Valor + "';");
	    		    	  }
	    		      }
	    		      
	    		      // cierre de la conexion
	    		      conBD.close();
	    		      
	    		      out.println("<html><body>");
	    		  		out.println("<h1>cambio realizado con exito</h1>");
	    		  		out.println("<a href=\"busqueda.jsp\">Volver</a>");
	    		  		out.println("</body></html>");
	    		   }else{
	    			   RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
	    			   rd.forward(request, response);
	    		   }
	    		      
	    		
	    	} catch (Exception error) {
	    		RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
				rd.forward(request, response);
	    	}
			break;
		}
	}

		// TODO Auto-generated method stub
		

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

/*

 */
